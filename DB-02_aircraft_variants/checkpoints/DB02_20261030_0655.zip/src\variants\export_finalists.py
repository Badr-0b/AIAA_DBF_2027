"""Export the finalist numbers the PDF cites (IDs F-...) to W/out/finalists/F_results.json, plus the P(1st) curves.
Run: PYTHONDONTWRITEBYTECODE=1 python src/variants/export_finalists.py"""
import json
import sys
from pathlib import Path

sys.dont_write_bytecode = True
W = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(W / "src"))
import numpy as np                                    # noqa: E402

FIN = json.loads((W / "out/integration/finalists.json").read_text(encoding="utf-8"))
ROWS = json.loads((W / "out/integration/finalists_rows.json").read_text(encoding="utf-8"))
GEO = json.loads((W / "out/variants/variants_geometry.json").read_text(encoding="utf-8"))
BT = json.loads((W / "out/field/backtest_orch.json").read_text(encoding="utf-8"))
SRC_FIN = "src/integration/finalists.py (orchestrator, 30 Oct 2026): 120 paired draws, reliability-aware declaration, 5,000 S2 v1 fields"
SRC_GEO = "src/variants/geometry_variants.py (orchestrator, 30 Oct 2026): AVL 3.52 wing+tail, DB-01 mass fit split by E02 shares"
items = {}


def put(i, name, v, unit, grade="computed", src=SRC_FIN, rng=None, note=""):
    d = {"name": name, "value": float(v) if isinstance(v, (int, float, np.floating)) else v, "unit": unit,
         "grade": grade, "source": src, "note": note}
    if rng is not None:
        d["range"] = [float(rng[0]), float(rng[1])]
    items[i] = d


MAP = {"CTRL": "C", "A": "A", "B10": "B", "B11": "B11", "TW": "TW", "A8": "A8"}
for cid, tag in MAP.items():
    s = FIN["base"][cid]
    put(f"F-{tag}-MEAN", f"{tag} mean mission total if completed", s["mean"], "points")
    put(f"F-{tag}-P10", f"{tag} P10 total", s["p10"], "points")
    put(f"F-{tag}-PTOP", f"{tag} P(top mission total)", s["p_mission_top"], "-", rng=s["p_mission_top_ci95"])
    put(f"F-{tag}-P1ST", f"{tag} P(1st), report 90", s["p_first"], "-", rng=s["p_first_ci95"])
    put(f"F-{tag}-RANK", f"{tag} expected rank", s["rank_mean"], "-")
    put(f"F-{tag}-PM2D", f"{tag} P(M2 completed)", s["p_m2_done"], "-")
    put(f"F-{tag}-PM3D", f"{tag} P(M3 completed)", s["p_m3_done"], "-")
    put(f"F-{tag}-PM2", f"{tag} per-attempt M2 success", s["pm2"], "-")
    put(f"F-{tag}-PM3", f"{tag} per-attempt M3 success", s["pm3"], "-")
    put(f"F-{tag}-M2", f"{tag} mean M2 score", s["M2"], "points")
    put(f"F-{tag}-M3", f"{tag} mean M3 score", s["M3"], "points")
    put(f"F-{tag}-GM", f"{tag} mean GM score", s["GM"], "points")
    put(f"F-{tag}-MDECL", f"{tag} mean declared sensor", s["m_decl_mean"], "kg")
    put(f"F-{tag}-VS2", f"{tag} median M2 stall speed", s["vs2"], "m/s")
    put(f"F-{tag}-G2", f"{tag} median M2 gross", s["g2"], "kg")
    put(f"F-{tag}-FEAS", f"{tag} P(M2 feasible)", s["p_feas"], "-")
    for sc in FIN:
        put(f"F-{tag}-PTOP-{sc}", f"{tag} P(top) in scenario {sc}", FIN[sc][cid]["p_mission_top"], "-",
            rng=FIN[sc][cid]["p_mission_top_ci95"])
# regret: best P(top) per scenario minus each candidate's
for sc in FIN:
    best = max(FIN[sc][c]["p_mission_top"] for c in FIN[sc] if c != "CTRL")
    for cid, tag in MAP.items():
        if cid == "CTRL":
            continue
        put(f"F-{tag}-REG-{sc}", f"{tag} regret in {sc}", best - FIN[sc][cid]["p_mission_top"], "-")
for cid, tag in MAP.items():
    if cid == "CTRL":
        continue
    put(f"F-{tag}-MAXREG", f"{tag} max regret", max(items[f'F-{tag}-REG-{sc}']['value'] for sc in FIN), "-")

# P(1st) against our report score
from field import model as fm                          # noqa: E402
rivals = fm.simulate(5000, 2027)
H = 1.524
curves = {}
for cid in ("A", "B10", "CTRL"):
    if cid == "CTRL":
        continue
    rr = ROWS["base"][cid]
    rows, pm2, pm3 = rr["rows"], np.array(rr["pm2"]), np.array(rr["pm3"])
    n = rivals.n
    idx = np.arange(n) % len(rows)
    feas = np.array([r["feas"] for r in rows])[idx]
    comp = fm.sample_completion(pm2[idx] * feas, pm3[idx], np.random.default_rng(11), n)
    our = {"m2_wt": np.array([r["w"] / r["t2"] if r["feas"] else 0.0 for r in rows])[idx],
           "m3_lxs": np.array([r["laps"] * r["m3"] for r in rows])[idx],
           "gm_wh": np.array([r["sensor_max"] * H for r in rows])[idx],
           "done_m1": comp["done_m1"], "done_m2": comp["done_m2"] & (feas > 0),
           "done_m3": comp["done_m3"] & (feas > 0), "done_gm": comp["done_gm"]}
    cv = fm.p_first_curve(our, rivals, report_scores=tuple(range(70, 97, 2)))
    curves[cid] = [(c.get("report_score", rs), c["p_first"]) for rs, c in zip(range(70, 97, 2), cv)]
for cid, tag in (("A", "A"), ("B10", "B")):
    d = dict(curves[cid])
    for rs in (80, 86, 90, 94):
        put(f"F-{tag}-P1ST-R{rs}", f"{tag} P(1st) at report {rs}", d.get(rs, np.nan), "-")

# geometry and stability
for key in ("A", "B"):
    g, t, m = GEO[key]["geometry"], GEO[key]["tails"], GEO[key]["mass"]
    G = lambda i, n, v, u, gr="computed", note="": put(f"F-{key}-{i}", n, v, u, gr, SRC_GEO, note=note)
    G("S", "wing area", g["S"], "m²"); G("AR", "aspect ratio", g["AR"], "-"); G("CR", "root chord", g["cr"], "m")
    G("CT", "tip chord", g["ct"], "m"); G("MAC", "mean aerodynamic chord", g["mac"], "m")
    G("SH", "horizontal tail area", t["Sh"], "m²"); G("SV", "fin area", t["Sv"], "m²"); G("LT", "tail arm", t["lt"], "m")
    G("BH", "horizontal tail span", t["bh"], "m"); G("BV", "fin height", t["bv"], "m")
    G("XNP", "neutral point (wing+tail, AVL)", t["xnp"], "m"); G("XCG", "design CG", t["x_cg_design"], "m")
    G("CLA", "lift-curve slope (AVL)", t["CLa"], "1/rad"); G("CMA", "Cm_alpha (AVL)", t["Cma"], "1/rad")
    G("CNB", "Cn_beta (AVL)", t["Cnb"], "1/rad"); G("CLB", "Cl_beta (AVL)", t["Clb"], "1/rad")
    G("EMPTY", "empty mass with 8S pack and D&R", m["empty"], "kg", "estimate", "DB-01 fit 5.96 S^0.94 (x1.31 scatter)")
    G("LEN", "overall length", t["x_ach"] + 0.6 * t["crh"], "m")
    sms = [r["sm"] for r in m["loadings"]]
    G("SMMIN", "static margin, worst loading (wing+tail)", min(sms) * 100, "%")
    G("SMMAX", "static margin, best loading (wing+tail)", max(sms) * 100, "%")
    G("M2G", "M2 gross at 6 kg declared", m["loadings"][1]["mass_kg"], "kg", "estimate")

# field back-test and propulsion facts
put("F-FLD-2027-P50", "2027 best rival mission total, median", 6.62, "points", src="out/field/backtest_orch.json + S2 v1")
put("F-FLD-2027-P10", "2027 best rival mission total, P10", 6.22, "points", src="S2 v1 simulate(5000, 2027)")
put("F-FLD-2027-P90", "2027 best rival mission total, P90", 7.04, "points", src="S2 v1 simulate(5000, 2027)")
put("F-FLD-GMRIV", "2027 rival GM maximum, median", 11.41, "kg m", src="S2 v1 simulate(5000, 2027)")
for y, d in BT.items():
    put(f"F-BT-{y}-WIN", f"{y} actual winner total", d["win"], "points", "verified", "analysis/data/dbf_results.csv")
    put(f"F-BT-{y}-SIM50", f"{y} simulated winner median", d["sim"][1], "points", src="S2 v1 back-test")
put("F-FUSE-100-32", "Littelfuse 100 A MAXI DC rating", 32, "V", "verified",
    "Littelfuse MAXI 32 V datasheet and MAXI Smart Glow sheet (via Digikey/Mouser-hosted copies, read 29 Oct 2026)")
put("F-FUSE-58-MAXA", "Littelfuse MAXI 58 V series, highest rating", 80, "A", "reseller", "Digikey 0999080-ZXN listing, 29 Oct 2026")
put("F-PROP-T0", "8S AT7215 KV270 + 20x15E static thrust", 101.3, "N", "computed", "analysis/out/prop_trade_report.txt")
put("F-PROP-MAXG", "8S max M2 gross at 80 % usable, S 1.0", 17.48, "kg", "computed", "out/propulsion/gross_sweep.json (S6, salvaged)")
put("F-PROP-AXH", "prop axis height for 20 in prop clearance", 0.369, "m", "computed", "out/propulsion/install.json (S6, salvaged)")

(W / "out/finalists").mkdir(exist_ok=True)
(W / "out/finalists/F_results.json").write_text(json.dumps({"schema": 1, "stream": "finalists",
                                                           "generated": "2026-10-30", "items": items}, indent=1),
                                               encoding="utf-8")
(W / "out/finalists/p1st_curves.json").write_text(json.dumps(curves), encoding="utf-8")
print(len(items), "items;", {k: [round(p, 3) for _, p in v][:14] for k, v in curves.items()})
